export const metadata = {
  title: "Login - YO! GREEK",
  description: "Login to your YO! GREEK account",
}

export default function LoginLayout({ children }) {
  return <>{children}</>
}

